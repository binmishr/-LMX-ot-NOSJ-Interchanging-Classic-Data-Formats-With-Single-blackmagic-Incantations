global.incant = require('xml-js');
