library(testthat)
test_check("blackmagic")
